/*
 * Copyright (C) 2011 by Jonathan Vasquez
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * */

import java.util.Scanner;

public class ExpGenTester {
	public static void main(String[] args) {
		
		// Constants
		final String PROGRAM_NAME = "Diablo II Experience Generator";
		final String PROGRAM_VERSION = "1.0.0";
		final String PROGRAM_LICENSE = "MIT License";
		final String PROGRAM_AUTHOR = "Jonathan Vasquez";

		// Header
		System.out.println("Welcome to " + PROGRAM_NAME + " " + PROGRAM_VERSION);
		System.out.println("By " + PROGRAM_AUTHOR);
		System.out.println("Distributed under the " + PROGRAM_LICENSE);
		System.out.println("");
		
		ExpGen gen;
		
		// IO Stuff
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter Max Level: ");
		int maxLevel = in.nextInt();
		System.out.print("Enter Maximum XP: ");
		double maxExp = in.nextDouble();
		System.out.print("Enter Default Exp Ratio: ");
		double defaultExpRatio = in.nextDouble();
		
		System.out.print("Do you want to use ratio tuning?[0 = no; 1 = yes]: ");
		
		int decision = in.nextInt();
		
		switch(decision) {
		case 1:
			double ratios[] = new double[10];
			
			// initialize all doubles
			for(int index = 0; index < ratios.length; index++)
				ratios[index] = 0.0;
			
			System.out.print("Enter ratio 1: ");
			ratios[0] = in.nextDouble();
			System.out.print("Enter ratio 2: ");
			ratios[1] = in.nextDouble();
			System.out.print("Enter ratio 3: ");
			ratios[2] = in.nextDouble();
			System.out.print("Enter ratio 4: ");
			ratios[3] = in.nextDouble();
			System.out.print("Enter ratio 5: ");
			ratios[4] = in.nextDouble();
			System.out.print("Enter ratio 6: ");
			ratios[5] = in.nextDouble();
			System.out.print("Enter ratio 7: ");
			ratios[6] = in.nextDouble();
			System.out.print("Enter ratio 8: ");
			ratios[7] = in.nextDouble();
			System.out.print("Enter ratio 9: ");
			ratios[8] = in.nextDouble();
			System.out.print("Enter ratio 10: ");
			ratios[9] = in.nextDouble();
			
			gen = new ExpGen(maxLevel, maxExp, defaultExpRatio, true);
			gen.setDivideRatios(ratios[0], ratios[1], ratios[2], ratios[3], ratios[4], ratios[5], ratios[6], ratios[7], ratios[8], ratios[9]);
			gen.generate();	
			
			break;
		case 0:
			gen = new ExpGen(maxLevel, maxExp, defaultExpRatio, false);
			gen.generate();	
			break;
		}	
	}
}
