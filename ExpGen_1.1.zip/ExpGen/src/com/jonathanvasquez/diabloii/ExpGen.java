/*
 * Copyright (C) 2011 by Jonathan Vasquez
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * */

package com.jonathanvasquez.diabloii;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.NumberFormat;

public class ExpGen {
	public ExpGen(int aMaxLevel, double anEndGoal, double aDivideRatio, boolean RATIOTUNING) {
		endGoal = anEndGoal;
		currentDivideRatio = aDivideRatio;
		currentValue = anEndGoal;
		maxLevel = aMaxLevel;
		USERATIOTUNING = RATIOTUNING;
	}
	
	public void generate() {
		// Formats decimals
		NumberFormat formatter = NumberFormat.getNumberInstance();
		
		formatter.setGroupingUsed(false);
		formatter.setMinimumFractionDigits(0);
		formatter.setMaximumFractionDigits(0);
		
		try {
			String fileName = "Experience.txt";
			
			FileWriter fwriter = new FileWriter(fileName);
			BufferedWriter out = new BufferedWriter(fwriter);
			
			// Start generating the Experience.txt file
			out.write("Note:\n");
			out.write("-----\n");
			out.write("The values below are printed from highest to lowest because of the algorithm used to calculate all the values.\n");
			out.write("Use a spreadsheet application to sort the values to ascending order.\n\n");
			out.write("Information\n");
			out.write("-----------\n");
			out.write("Max Level: " + maxLevel + "\n");
			out.write("Maximum Exp: " + formatter.format(endGoal) + "\n\n");
			
			out.write("Ratio(s) Used:\n");
			out.write("--------------\n");
			
			if(USERATIOTUNING == true) 
				for(int i = 0; i < ratios.length; i++) 
					out.write("Ratio " + (i+1) + " is " + ratios[i] + "\n");
			else 
				out.write("Ratio is " + currentDivideRatio + "\n");
			
			out.write("\n");
			out.write("Generating Table:" + "\n");
			out.write("-----------------\n");
			
			out.write(formatter.format(endGoal) + "\n");
			
			for(int i = maxLevel; i > 1; i--) {
				
				// Are you using the ratio tuner?
				if(USERATIOTUNING == true) 
					ratioSwitcher(i);
				
				// Print the values
				out.write(formatter.format(divider()) + "\n");
			}
			out.close();
			
			System.out.println("The file has been created as " + fileName);
		}
		catch(Exception e) {
			System.err.println("Error: " + e.getMessage());
		}
	}
	
	public void setDivideRatios(double theRatios[]) {
		
		// Save the ratios
		ratios = theRatios;
		
		// Set the ratios
		firstDivideRatio = theRatios[0];
		secondDivideRatio = theRatios[1];
		thirdDivideRatio = theRatios[2];
		fourthDivideRatio = theRatios[3];
		fifthDivideRatio = theRatios[4];
		sixthDivideRatio = theRatios[5];
		seventhDivideRatio = theRatios[6];
		eighthDivideRatio = theRatios[7];
		ninthDivideRatio = theRatios[8];
		tenthDivideRatio = theRatios[9];
	}
	
	// Not used, but someone could make use of this
	public double[] getDivideRatios() {
		return ratios;
	}
	
	private double divider() {
		return currentValue /= currentDivideRatio;
	}
	
	private void ratioSwitcher(int theLevel) {
		int i = theLevel;
		
		// meaning it's a 10th level
		if((i % 10) == 0 && i == maxLevel && firstDivideRatio != 0) {
			// then switch divide ratio
			currentDivideRatio = firstDivideRatio;
		} 
		else if((i % 10) == 0 && i == 90 && secondDivideRatio != 0) {
			currentDivideRatio = secondDivideRatio;
		}
		else if((i % 10) == 0 && i == 80 && thirdDivideRatio != 0) {
			currentDivideRatio = thirdDivideRatio;
		}
		else if((i % 10) == 0 && i == 70 && fourthDivideRatio != 0) {
			currentDivideRatio = fourthDivideRatio;
		}
		else if((i % 10) == 0 && i == 60 && fifthDivideRatio != 0) {
			currentDivideRatio = fifthDivideRatio;
		}
		else if((i % 10) == 0 && i == 50 && sixthDivideRatio != 0) {
			currentDivideRatio = sixthDivideRatio;
		}
		else if((i % 10) == 0 && i == 40 && seventhDivideRatio != 0) {
			currentDivideRatio = seventhDivideRatio;
		}
		else if((i % 10) == 0 && i == 30 && eighthDivideRatio != 0) {
			currentDivideRatio = eighthDivideRatio;
		}
		else if((i % 10) == 0 && i == 20 && ninthDivideRatio != 0) {
			currentDivideRatio = ninthDivideRatio;
		}
		else if((i % 10) == 0 && i == 10 && tenthDivideRatio != 0) {
			currentDivideRatio = tenthDivideRatio;
		} 
	}
	
	// Variables
	private double endGoal;
	private double currentValue;
	private double currentDivideRatio;
	private int maxLevel;
	
	// Divide Ratios - Reaching the specified level
	private double firstDivideRatio; // Level 90
	private double secondDivideRatio; // Level 80
	private double thirdDivideRatio; // Level 70
	private double fourthDivideRatio; // Level 60
	private double fifthDivideRatio; // Level 50
	private double sixthDivideRatio; // Level 40
	private double seventhDivideRatio; // Level 30
	private double eighthDivideRatio; // Level 20
	private double ninthDivideRatio; // Level 10
	private double tenthDivideRatio; // Level 1
	private double[] ratios; // All ratios
	
	// CONSTANTS
	private boolean USERATIOTUNING = false;
}
