Usage: 

Open up command prompt or a terminal and change directory to the ExpGen folder

cd ExpGen

once in the ExpGen folder, tell java to open up the generator as a jar.

java -jar ExpGen.jar

Enjoy!

Ratio Tuning:

If you decide to use Ratio Tuning, basically what it does is that it will divide the
previous value (from whatever level it was at) by the new ratio and continue on dividing
until it either reaches level 1 or reaches the next divide ratio, which will then repeat
the process.

First Divide Ratio = What ratio to use to get from 100 to 90.

Second Divide Ratio = What ratio to use to get from 90 to 80.

etc.